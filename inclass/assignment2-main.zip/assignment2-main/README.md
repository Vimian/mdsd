# Assignment 2: External DSL interpreter

Base repository of the model-driven software development assignment 2: External DSL and interpreter.
This repository provides an incomplete Xtext grammar and Xtend generator file.
The Xtend file works as an interpreter instead of a generator.
Moreover, it also provides several 4 test files that test parsing, validation, scope, and all things combined.
